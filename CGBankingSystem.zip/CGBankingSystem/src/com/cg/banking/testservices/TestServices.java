package com.cg.banking.testservices;
import java.util.HashMap;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;
import com.cg.banking.util.BankingDB;
public class TestServices {
	private static BankingServices services;
	@BeforeClass
	public static void setUpTestEnv() {
		services=new BankingServicesImpl();
	}
	@Before
	public void setUpTestData() {
		HashMap<Integer, Transaction> transaction1=new HashMap<>();
		HashMap<Integer, Transaction> transaction2=new HashMap<>();
		transaction1.put(1001,new Transaction(1001, 2000, "deposit"));
		transaction2.put(1002,new Transaction(1002, 2000, "savings"));
		Account account1=new Account(12300018, 1000, "savings","active",  6000, transaction1);
		Account account2=new Account(12300019, 1001, "current", "active", 6500,transaction2);
		BankingDB.accountDB.put(account1.getAccountNo(), account1);
		BankingDB.accountDB.put(account2.getAccountNo(), account2);
		BankingDB.ACCOUNT_NUMBER=12300020;
		BankingDB.ACCOUNT_PIN=1001;
		BankingDB.ACCOUNT_STATUS="active";
	}
	@Test(expected=InvalidAccountTypeException.class)
	public void testOpenAccountForInvalidDataAccountType() throws InvalidAccountTypeException{
		services.openAccount("savhd", 12000);
	}
	@Test(expected=InvalidAmountException.class)
	public void testOpenAccountForInvalidDataInvalidAmount() throws InvalidAmountException{
		services.openAccount("savings", 100);
	}
	@Test
	public void testOpenAccountForValidData() {
		HashMap<Integer, Transaction> transactionExpected=new HashMap<>();
		Account actualData=services.openAccount("savings", 12000);
		Account expectedData=new Account(12300020, 1002, "savings", "active", 12000,transactionExpected);
		Assert.assertEquals(expectedData, actualData);
	}
	@Test(expected=AccountNotFoundException.class)
	public void testDepositAmountForInvalidData() throws AccountNotFoundException{
		services.depositAmount(12300299, 23231);
	}
	@Test
	public void testDepositAmountForValidData() throws AccountNotFoundException{
		Assert.assertEquals(7000,services.depositAmount(12300018, 1000), 0);
	}
	@Test(expected=AccountNotFoundException.class)
	public void testWithrawAmountForInvalidDataAccountNotFound() throws AccountNotFoundException{
		services.withdrawAmount(123000220, 1000, 1001);
	}
	@Test(expected=InvalidPinNumberException.class)
	public void testWithrawAmountForInvalidDataInvalidPin() throws InvalidPinNumberException{
		services.withdrawAmount(12300018, 1000, 1001);
	}
	@Test(expected=InsufficientAmountException.class)
	public void testWithdrawForInsufficientAmountData() throws InsufficientAmountException{
		services.withdrawAmount(12300018, 10000, 1000);
	}
	@Test
	public void testWithdrawAmountForValidData() {
		Assert.assertEquals(2000, services.withdrawAmount(12300018, 4000, 1000), 0);
	}
	@Test
	public void testGetAccountDetailsForValidData() {
		HashMap<Integer, Transaction> transaction1=new HashMap<>();
		transaction1.put(1001,new Transaction(1001, 2000, "deposit"));
		Account actualData=services.getAccountDetails(12300018);
		Account expectedData=new Account(12300018, 1000, "savings","active",  6000, transaction1);
		Assert.assertEquals(expectedData, actualData);
	}
	@Test(expected=AccountNotFoundException.class)
	public void testGetAccountDetailsForInvalidData() throws AccountNotFoundException {
		services.getAccountDetails(12300028);
	}
	@Test(expected=AccountNotFoundException.class)
	public void testGetTransactionDetailsForInvalidData() throws AccountNotFoundException{
		services.getAccountAllTransaction(1234545);
	}
	@Test
	public void testGetTrasanctionDetailsForValidData() {

	}
	@After
	public void tearDownData() {
		BankingDB.accountDB.clear();
		BankingDB.ACCOUNT_NUMBER=12300018;
	}
	@AfterClass
	public static void tearDownEnv() {
		services=null;
	}

}
