
import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.exceptions.AssociateDetailNotfoundException;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;
import com.cg.payroll.util.PayrollDBUtil;


public class PayrollTest {
public static PayrollServices services;

@BeforeClass
public static void setUpTestEnv() {
    services=new PayrollServicesImpl(); 
}
@Before
public void setUpTestData() {
    Associate associate1=new Associate(101,78000,"abhi","sapahia","a4","analyst","DTDYF736",
            "abhi@gmail.com",new Salary(35000,1800,200),new BankDetails(12345,"PNB","qwerty"));
    
    Associate associate2=new Associate(102,78000,"abhi","sapahia","a4","analyst","DTDYF736",
            "abhi@gmail.com",new Salary(35000,1800,200),new BankDetails(12345,"PNB","qwerty"));
    
    PayrollDBUtil.associates.put(associate1.getAssociateId(), associate1);

    PayrollDBUtil.associates.put(associate2.getAssociateId(), associate2);
    PayrollDBUtil.ASSOCIATE_ID_COUNTER=102;
}

@Test
public void testGetAssociateDetailsForValidAssociateId()throws AssociateDetailNotfoundException
{
    Associate expectedAssociate = new Associate(102,78000,"abhi","sapahia","a4","analyst","DTDYF736",
            "abhi@gmail.com",new Salary(35000,1800,200),new BankDetails(12345,"PNB","qwerty"));
    Associate actualAssociate=services.getAssociateDetails(102);
    Assert.assertEquals(expectedAssociate, actualAssociate);
}
@Test
public void testAcceptAssociateDetailsForValidData() {
    int expectedId=103;
    int actualId=services.acceptAssociateDetails("ab", "sap", "andnadn@fdhg", "eee", "deposite"," pan", 12345, 4567, 456, 789, 45456, "pnb", "gtersyn");
Assert.assertEquals(expectedId, actualId);
}
@Test(expected=AssociateDetailNotfoundException.class)
public void testCalculateNetSalaryForInvalidAssociateId() throws AssociateDetailNotfoundException{
    services.calculateNetSalary(1234);
}
@Test
public void testCalculateNetSalaryForValidAssociateId() throws AssociateDetailNotfoundException{
int expectedNetSalary=652200;
int actualNetSalary=services.calculateNetSalary(102);
Assert.assertEquals(expectedNetSalary, actualNetSalary);
}
@Test
public void testGetAllAssociatesDetails() {
    Associate associate1=new Associate(101,78000,"abhi","sapahia","a4","analyst","DTDYF736",
            "abhi@gmail.com",new Salary(35000,1800,200),new BankDetails(12345,"PNB","qwerty"));
    
    Associate associate2=new Associate(102,78000,"abhi","sapahia","a4","analyst","DTDYF736",
            "abhi@gmail.com",new Salary(35000,1800,200),new BankDetails(12345,"PNB","qwerty"));
    ArrayList<Associate>expectedAssociateList=new ArrayList<Associate>();
    expectedAssociateList.add(associate1);
    expectedAssociateList.add(associate2);
    ArrayList<Associate>actualAssociateList=(ArrayList<Associate>)services.getallAssociateDetails();
    Assert.assertEquals(expectedAssociateList, actualAssociateList);
}

@After
public void tearDownTestData() {
    PayrollDBUtil.associates.clear();
    PayrollDBUtil.ASSOCIATE_ID_COUNTER=100;
}
@AfterClass
public static void tearUpTestEnv() {
    services=null;
}
}