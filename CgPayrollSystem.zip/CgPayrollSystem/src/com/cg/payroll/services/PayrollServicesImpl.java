 package com.cg.payroll.services;

import java.util.List;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.daoservices.AssociateDAO;
import com.cg.payroll.daoservices.AssociateDAOImpl;
import com.cg.payroll.exceptions.AssociateDetailNotfoundException;

public class PayrollServicesImpl implements PayrollServices{

	private AssociateDAO associateDao;
	
	 public PayrollServicesImpl() {
		associateDao=new AssociateDAOImpl();
	}
	public PayrollServicesImpl(AssociateDAO associateDao)
	{
		super();
		this.associateDao=associateDao;
	}
	
	@Override
	public int acceptAssociateDetails(String firstName, String lastName, String emailId, String department,
			String designation, String pancard, int yearIyinvestmentUnder8oC, int basicSalary, int epf, int companyPf,
			int accountNumber, String bankName, String ifscCode) {
		BankDetails bankDetails=new BankDetails(accountNumber, bankName, ifscCode);
		Salary sal=new Salary(basicSalary, epf, companyPf);
		Associate associate=new Associate(yearIyinvestmentUnder8oC, accountNumber, firstName, lastName, department, designation, pancard, emailId,sal,bankDetails);
		
		associate=associateDao.save(associate);
		return associate.getAssociateId();
	}

	@Override
	public int calculateNetSalary(int associateId) throws AssociateDetailNotfoundException {
		Associate associate=associateDao.findOne(associateId);
		int netSalary=0;
		if(associate==null)
			throw new AssociateDetailNotfoundException("Associate details not found for id:"+associateId);
		
		else {
			int basicSal=associate.getSal().getBasicSalary();
			int monthlyGrossSal=(int)(basicSal+(basicSal*0.7));
			int annualGrossSal=12*monthlyGrossSal;
			int investment=associate.getYearlyInvestmentUnder8oC()+associate.getSal().getEpf()+associate.getSal().getCompanyPf();
			if(investment>=150000)
				investment=150000;
			
			if(annualGrossSal<250000)
				 netSalary=annualGrossSal-associate.getSal().getEpf()-associate.getSal().getCompanyPf();
			
			else if(annualGrossSal>=250000 && annualGrossSal<500000)
				netSalary=annualGrossSal-associate.getSal().getEpf()-associate.getSal().getCompanyPf();
			
			else if(annualGrossSal>=500000 && annualGrossSal<1000000) {
				int tax1=(int)((annualGrossSal-500000)*0.2);
				int tax2=(int)((250000-investment)*0.1);
				netSalary=annualGrossSal-tax1-tax2-associate.getSal().getEpf()-associate.getSal().getCompanyPf();
			}
			
			else if(annualGrossSal>=1000000) {
				int tax3=(int)((annualGrossSal-100000)*0.3);
				int tax2=100000;
				int tax1=(int)((250000-investment)*0.1);
				netSalary=annualGrossSal-tax1-tax2-tax3-associate.getSal().getEpf()-associate.getSal().getCompanyPf();
			}
			return netSalary;
		}
	}

	@Override
	public Associate getAssociateDetails(int associateId) throws AssociateDetailNotfoundException {
		Associate associate=associateDao.findOne(associateId);
		if(associate==null)
			throw new AssociateDetailNotfoundException("Associate detail not found for id"+associateId);
		return associate;
	}

	@Override
	public List<Associate> getallAssociateDetails() {
		return associateDao.findAll();
	}
	//private AssociateDAO associateDao=new Associate();
	
}
