package com.cg.payroll.client;

import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;
import com.cg.payroll.util.PayrollDBUtil;
public class MainClass {

	public static void main(String ...args)
	{
		PayrollServices services=new PayrollServicesImpl();
		int associateId1=services.acceptAssociateDetails("Abhishek", "Mathpal", "abhideinesta60@gmail.com", "IT", "analyst", "EY50005", 1000, 40000, 1200, 1400, 1234567, "ICICI", "icici0006");
		int associateId2=services.acceptAssociateDetails("Abhi", "sharma", "abhi@gmail.com", "IT", "programmer", "EY50006", 1200, 42000, 1200, 2400, 1234667, "ICICI", "icici0006");
		System.out.println(PayrollDBUtil.associates.get(associateId1));
		System.out.println(PayrollDBUtil.associates.get(associateId2));
		System.out.println("Net Salary of E1:"+services.calculateNetSalary(associateId1));
		System.out.println("Net Salary of E2:"+services.calculateNetSalary(associateId2));
		System.out.println("get all associate details"+services.getallAssociateDetails());
		System.out.println("Get associate detials:"+services.getAssociateDetails(associateId1));
	}
	
}
