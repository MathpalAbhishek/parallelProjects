import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.daoservices.AssociateDAO;
import com.cg.payroll.exceptions.AssociateDetailNotfoundException;
import com.cg.payroll.services.PayrollServices;
import static org.junit.Assert.*;

import java.util.ArrayList;

import com.cg.payroll.beans.*;
import org.easymock.EasyMock;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.Test;
public class PayrollServicesTestEasyMock {
	private static PayrollServices payrollServices;
	private static AssociateDAO mockAssociateDao;
	@Before
	public void setUpTestmockData() {
		mockAssociateDao=EasyMock.mock(AssociateDAO.class);
		
	}
	@Before
	public void setUpTestMockData()
	{
		BankDetails bankDetails=new BankDetails(13213, "xyz", "342");
		Salary sal=new Salary(35000, 1800, 2000);
		Associate associate=new Associate(50000, 321132, "abhi", "mathpal", "TRAINING", "trainee", "ew3214", "dsadsa@gmail.com",sal,bankDetails);
	
		BankDetails bankDetails1=new BankDetails(13214, "xyz", "343");
		Salary sal1=new Salary(38000, 1900, 2100);
		Associate associate1=new Associate(50000, 321132, "abhishek", "mathpal", "TRAINING", "trainee", "ew3214", "dsadsaaa@gmail.com",sal1,bankDetails1);
	
		ArrayList<Associate> associateList=new ArrayList<>();
		associateList.add(associate);
		associateList.add(associate1);
		EasyMock.expect(mockAssociateDao.save(associate1)).andReturn(associate1);
		
		EasyMock.expect(mockAssociateDao.findOne(101)).andReturn(associate);
		EasyMock.expect(mockAssociateDao.findOne(102)).andReturn(associate1);
		EasyMock.expect(mockAssociateDao.findOne(13443)).andReturn(null);
		EasyMock.replay(mockAssociateDao);
	}
	@Test(expected=AssociateDetailNotfoundException.class)
	public void testGetAssociateDataForInvalidAssociateId()
	throws AssociateDetailNotfoundException
	{
		Associate expAssociate=new Associate(213,4321,"asdh","affaas","training","trainee","dsa432","abhi@gmail.com",new Salary(20000,3213,4321,4321,321,321,321,321,321,321),new BankDetails(4321321,"xyz","98ujh"));
		Associate actualAssociate=payrollServices.getAssociateDetails(101);
		assertEquals(expAssociate,actualAssociate);
		EasyMock.verify(mockAssociateDao.findOne(101));	
	}
	
	@After
	public void tearDownTestMockData()
	{
		EasyMock.resetToDefault(mockAssociateDao);
	}
	
	@AfterClass
	public static void tearDownTestEnv() {
		mockAssociateDao=null;
		payrollServices=null;
	}
}
