import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.gymsystem.beans.Date;
import com.cg.gymsystem.beans.Member;
import com.cg.gymsystem.beans.Trainee;
import com.cg.gymsystem.beans.Trainer;
import com.cg.gymsystem.exception.MemberNotFoundException;
import com.cg.gymsystem.exception.WrongDateFormatException;
import com.cg.gymsystem.services.GymSystemServices;
import com.cg.gymsystem.services.GymSystemServicesImpl;
import com.cg.gymsystem.util.GymSysDBUtil;





public class GymSystemTest {
	public static GymSystemServices memb;
	
	@BeforeClass
	public static void setUpTestEnv() {
	    memb=new GymSystemServicesImpl(); 
	}
	@Before
	public void setUpTestData() {
	   Member mem=new Member(new Date(14,7,2018),new Trainer("Abhi", 20, "43tr54", 20000,1002),new Trainee("Nandan",1001, 18, 50.0f, 1.9f),1000);
	    
	   Member mem1=new Member(new Date(14,7,2018),new Trainer("Abhishek", 21, "43ew54", 22000,1005),new Trainee("Sapahia", 1004,20, 50.0f, 1.9f),1003);
	    
	    
	    GymSysDBUtil.members.put(mem.getMemberId(), mem);
	    GymSysDBUtil.members.put(mem1.getMemberId(), mem1);
	    GymSysDBUtil.Mem_ID=1005;
	}
	@Test
	public void testGetMemberDetailsForValidMemberID()throws MemberNotFoundException,WrongDateFormatException
	{
	   Member expectedMem = new Member(new Date(14,7,2018),new Trainer("Abhi", 20, "43tr54", 20000,1002),new Trainee("Nandan",1001, 18, 50.0f, 1.9f),1000);
		Member actualMem=memb.getDetails(1000);
		Assert.assertEquals(expectedMem, actualMem);
	}
	
	@Test(expected=MemberNotFoundException.class)
	public void testCalculateNetSalaryForInvalidAssociateId() throws MemberNotFoundException{
	    memb.getDetails(1234);
	}
	@After
	public void tearDownTestData() {
	    GymSysDBUtil.members.clear();
	    GymSysDBUtil.Mem_ID=1000;
	}
	@AfterClass
	public static void tearUpTestEnv() {
	    memb=null;
	}
}
