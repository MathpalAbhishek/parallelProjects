package com.cg.gymsystem.main;

import com.cg.gymsystem.beans.Member;
import com.cg.gymsystem.services.GymSystemServices;
import com.cg.gymsystem.services.GymSystemServicesImpl;
import com.cg.gymsystem.servicesDao.GymSystemServicesDao;

public class MainClass {
	private static GymSystemServices obj=new GymSystemServicesImpl();
	public static void main(String ...args)
	{
		Member m=obj.saveDetails("ABHISHEK", 20, 50.8f, 1.9f, 15, 07, 2018, "ewqr432", "32423432234", 20000);
		System.out.println(m.getTrainee().getName());
		System.out.println(m.getMemberId());
		System.out.println(obj.getDetails(m.getMemberId()));
	}
}
