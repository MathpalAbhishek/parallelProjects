package com.cg.gymsystem.beans;

public class Trainer {
	String name;
	int age;
	String pan;
	float salary;
	int trainerId;
	public Trainer(String name, int age, String pan, float salary) {
		super();
		this.name = name;
		this.age = age;
		this.pan = pan;
		this.salary = salary;
	}
	
	
	public Trainer(String name, int age, String pan, float salary, int trainerId) {
		super();
		this.name = name;
		this.age = age;
		this.pan = pan;
		this.salary = salary;
		this.trainerId = trainerId;
	}


	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getPan() {
		return pan;
	}
	public void setPan(String pan) {
		this.pan = pan;
	}
	public float getSalary() {
		return salary;
	}
	public void setSalary(float salary) {
		this.salary = salary;
	}
	
	public int getTrainerId() {
		return trainerId;
	}


	public void setTrainerId(int trainerId) {
		this.trainerId = trainerId;
	}


	@Override
	public String toString() {
		return "Trainer [name=" + name + ", age=" + age + ", pan=" + pan + ", salary=" + salary + ", trainerId="
				+ trainerId + "]";
	}



	
}
